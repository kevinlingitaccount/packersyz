package com.example.packers.presentation.utils

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

abstract class BaseViewHolder(binding: ViewGroup) : RecyclerView.ViewHolder(binding)